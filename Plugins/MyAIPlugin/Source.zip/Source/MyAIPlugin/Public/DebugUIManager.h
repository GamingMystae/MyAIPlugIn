// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "DebugUIManager.generated.h"

class UMyAIPluginSettings;

UCLASS()
class MYAIPLUGIN_API ADebugUIManager : public AActor
{
    GENERATED_BODY()

public:
    ADebugUIManager();

    UFUNCTION(BlueprintCallable, Category = "AI Debug")
    void ToggleDebugUI();

    UFUNCTION(BlueprintCallable, Category = "AI Debug")
    void SetCombatStyle(EAICombatStyle NewStyle);

    UFUNCTION(BlueprintCallable, Category = "AI Debug")
    void SetPatrolStyle(EPatrolMode NewMode);

    /** The Debug UI Widget Blueprint */
    UPROPERTY(EditAnywhere, Category = "UI")
    TSubclassOf<UUserWidget> DebugWidgetClass;


protected:
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaTime) override;

private:
    /** Actual UI instance */
    UPROPERTY()
    UUserWidget* DebugWidget;

    /** Show/hide flag */
    bool bIsVisible = false;

    /** Runtime access to settings */
    UPROPERTY()
    UMyAIPluginSettings* RuntimeSettings;
};
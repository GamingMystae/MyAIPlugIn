// Fill out your copyright notice in the Description page of Project Settings.

/********************************
** MY CUSTOM AI CONTOLER HEADER *
*********************************/

#pragma once

#include "CoreMinimal.h"
#include "AICharacterTypes.h"
#include "AIController.h"
#include "MyAIController.generated.h"

class APawn;
class APatrolPath;
class ASplinePath;
class UMyAIPluginSettings;

UCLASS()
class MYAIPLUGIN_API AMyAIController : public AAIController // inherits from the default unreal AIController class
{
	GENERATED_BODY()
	
public:
	AMyAIController(); // new constructor

protected:
	virtual void BeginPlay() override; // override the default begin play will initialize the behavior of ai when the game starts
	
	UFUNCTION(BlueprintCallable, Category = "AI")
	void InitializePatrolPath();

	/*************
	* REFERENCES *
	*************/
	UPROPERTY()
	APawn* PlayerPawn;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol")
	APatrolPath* PatrolPath;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Patrol")
	ASplinePath* SplinePath;

	UPROPERTY()
	TArray<AActor*> PatrolPoints;

	/*************
	* AI STATE *
	*************/
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "AI Properties")
	EAIState CurrentAIState = EAIState::EAIS_Idle;

	/*************
	* NAVIGATION *
	*************/
	void TickBehavior();

	FTimerHandle PatrolTimerHandle;
	FTimerHandle SplineMoveTimerHandle;
	FTimerHandle SplineWaitTimerHandle;
	FTimerHandle WaypointWaitTimerHandle;
	
		
	void MoveToNextPatrolPoint();
	void MoveAlongSpline();
	void MoveToNextSplinePoint();
	void AdvanceSplineIndex();
	void AdvancePatrolIndex();

	bool HandleChaseBehavior(const UMyAIPluginSettings* Settings);

	void HandlePatrolBehavior(const UMyAIPluginSettings* Settings);
	void HandleWaypointPatrol(const UMyAIPluginSettings* Settings);
	void HandleSplinePatrol(const UMyAIPluginSettings* Settings);
	void HandleRandomPatrol(const UMyAIPluginSettings* Settings);
	
	

	int32 CurrentPatrolIndex = 0;
	int32 CurrentSplineIndex = 0;

	bool bReverseSpline = false;
	bool bInitialWaitDone = false;

	/***********
	* COMBAT *
	***********/
	void AttemptAttack();
	bool bWasChasing = false;

	FTimerHandle AttackTimerHandle;
	bool bCanAttack = true;
};

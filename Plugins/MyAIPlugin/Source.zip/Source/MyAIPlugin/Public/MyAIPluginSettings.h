/*****************************
** Custom Settings For User  *
*****************************/
#pragma once

#include "AICharacterTypes.h"
#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "MyAIPluginSettings.generated.h"

/**
 * 
 */
UCLASS(config = Game, defaultconfig)
class MYAIPLUGIN_API UMyAIPluginSettings : public UObject
{
    GENERATED_BODY()

public:

    /*************
    * NAVIGATION *
    *************/

    UPROPERTY(EditAnywhere, config, Category = "Patrolling")
    bool bEnablePatrol = true;

    UPROPERTY(EditAnywhere, config, Category = "Patrolling", meta = (ClampMin = "100.0", ClampMax = "5000.0"))
    float PatrolRadius = 1000.0f;

    UPROPERTY(EditAnywhere, config, Category = "Patrolling", meta = (ClampMin = "0.1", ClampMax = "10.0"))
    float PatrolInterval = 3.0f;

    UPROPERTY(EditAnywhere, config, Category = "Patrolling", meta = (ClampMin = "100.0", ClampMax = "1200.0"))
    float PatrolMoveSpeed = 600.0f;

    UPROPERTY(EditAnywhere, Config, Category = "Patrolling|Spline", meta = (ToolTip = "True: ReverseDirection / False: Loop"))
    bool bUsePingPongSpline = false;

    UPROPERTY(EditAnywhere, Config, Category = "Patrolling|Spline", meta = (ClampMin = "0.0", UIMin = "0.0"))
    float SplineWaitTime = 1.0f;

    UPROPERTY(EditAnywhere, config, Category = "Patrolling")
    EPatrolMode PatrolMode = EPatrolMode::EPM_Random;

   /***********
   *  COMBAT  *
   ***********/
    UPROPERTY(EditAnywhere, BlueprintReadWrite, config, Category = "Combat")
    EAICombatStyle DefaultCombatStyle = EAICombatStyle::EAIC_Aggressive;

    UPROPERTY(EditAnywhere, config, Category = "Combat")
    bool bEnableChase = true;

    UPROPERTY(EditAnywhere, config, Category = "Combat")
    bool bEnableAttack = true;

    UPROPERTY(EditAnywhere, config, Category = "Combat", meta = (ClampMin = "100.0", ClampMax = "5000.0"))
    float ChaseDistance = 800.0f;

    UPROPERTY(EditAnywhere, config, Category = "Combat", meta = (ClampMin = "50.0", ClampMax = "1000.0"))
    float AttackRange = 150.0f;

    UPROPERTY(EditAnywhere, config, Category = "Combat", meta = (ClampMin = "0.1", ClampMax = "10.0"))
    float AttackCooldown = 1.5f;


    UPROPERTY(EditAnywhere, config, Category = "Debug")
    bool bEnableDebugLogs = true;
};

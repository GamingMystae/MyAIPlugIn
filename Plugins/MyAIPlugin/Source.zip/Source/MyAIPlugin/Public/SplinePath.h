// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SplinePath.generated.h"

class USplineComponent;

UCLASS()
class MYAIPLUGIN_API ASplinePath : public AActor
{
	GENERATED_BODY()
	
public:	
	
	ASplinePath();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Spline")
	USplineComponent* SplineComponent;

	//Wai per-spline-point wait time, can be changed in BP
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI|Spline")
	TArray<float> WaitTimes;

protected:
	
	virtual void BeginPlay() override;

};

// Fill out your copyright notice in the Description page of Project Settings.

/********************************
** MY CUSTOM AI Character HEADER *
*********************************/
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "NPC_Character.generated.h"

class APatrolPath;
class ASplinePath;

UCLASS()
class MYAIPLUGIN_API ANPC_Character : public ACharacter // inherits from the default unreal character class
{
	GENERATED_BODY()

public:
	
	ANPC_Character();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI")
	APatrolPath* PatrolPath;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AI")
	ASplinePath* SplinePath;


protected:
	
	virtual void BeginPlay() override;
	
private:	

};

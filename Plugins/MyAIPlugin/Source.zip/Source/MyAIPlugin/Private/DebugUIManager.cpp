// Fill out your copyright notice in the Description page of Project Settings.
#include "DebugUIManager.h"
#include "Blueprint/UserWidget.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/PlayerController.h"
#include "MyAIPluginSettings.h"

ADebugUIManager::ADebugUIManager()
{
    PrimaryActorTick.bCanEverTick = true;
}

void ADebugUIManager::BeginPlay()
{
    Super::BeginPlay();

    RuntimeSettings = GetMutableDefault<UMyAIPluginSettings>();


    if (DebugWidgetClass)
    {
        DebugWidget = CreateWidget<UUserWidget>(UGameplayStatics::GetPlayerController(GetWorld(), 0), DebugWidgetClass);
        if (DebugWidget)
        {
            DebugWidget->AddToViewport();
            DebugWidget->SetVisibility(ESlateVisibility::Hidden);
        }
    }

    // Bind key
    if (APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0))
    {
        EnableInput(PC); // This sets `InputComponent` on this actor!

        if (InputComponent)
        {
            InputComponent->BindKey(EKeys::Tab, IE_Pressed, this, &ADebugUIManager::ToggleDebugUI);
        }
    }
}

void ADebugUIManager::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
}

void ADebugUIManager::ToggleDebugUI()
{
    if (!DebugWidget) return;

    bIsVisible = !bIsVisible;
    DebugWidget->SetVisibility(bIsVisible ? ESlateVisibility::Visible : ESlateVisibility::Hidden);
    APlayerController* PC = UGameplayStatics::GetPlayerController(GetWorld(), 0);
    if (PC)
    {
        PC->bShowMouseCursor = true;
        FInputModeUIOnly InputMode;
        InputMode.SetWidgetToFocus(DebugWidget->TakeWidget());
        InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
        PC->SetInputMode(InputMode);
    }
}

void ADebugUIManager::SetCombatStyle(EAICombatStyle NewStyle)
{
    if (RuntimeSettings)
    {
        RuntimeSettings->DefaultCombatStyle = NewStyle;
    }
}

void ADebugUIManager::SetPatrolStyle(EPatrolMode NewMode)
{
    if (RuntimeSettings)
    {
        RuntimeSettings->PatrolMode = NewMode;
    }
}




// Fill out your copyright notice in the Description page of Project Settings.

/*****************************
** MY CUSTOM AI CONTOLER CPP *
*****************************/

#include "MyAIController.h"
#include "NavigationSystem.h" //use the navigation system
#include "GameFramework/Character.h" // need it to use the character class
#include "MyAIPluginSettings.h"
#include "TimerManager.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"
#include "Engine/TargetPoint.h"
#include "PatrolPath.h"
#include "NPC_Character.h"
#include "Components/SplineComponent.h"
#include "SplinePath.h"

AMyAIController::AMyAIController()
{
    UE_LOG(LogTemp, Warning, TEXT("MyAIController Created!"));
}

void AMyAIController::BeginPlay()
{
    Super::BeginPlay();

    const UMyAIPluginSettings* Settings = GetDefault<UMyAIPluginSettings>();
    PlayerPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);

    if (Settings->bEnableDebugLogs)
    {
        UE_LOG(LogTemp, Warning, TEXT("MyAIController Initialized!"));
    }

    ACharacter* MyCharacter = Cast<ACharacter>(GetPawn());
    if (MyCharacter && Settings->bEnablePatrol)
    {
        UE_LOG(LogTemp, Warning, TEXT("AI Character Controlled by MyAIController: %s"), *MyCharacter->GetName());

        // Pull PatrolPath from character
        ANPC_Character* NPC = Cast<ANPC_Character>(MyCharacter);
        if (NPC && NPC->PatrolPath)
        {
            PatrolPath = NPC->PatrolPath;
            InitializePatrolPath(); // Load patrol points
        }
        if (Settings->PatrolMode == EPatrolMode::EPM_Spline)
        {
           // ANPC_Character* NPC = Cast<ANPC_Character>(GetPawn());
            if (NPC && NPC->SplinePath)
            {
                SplinePath = NPC->SplinePath;
                UE_LOG(LogTemp, Warning, TEXT("Spline Path Set: %s"), *SplinePath->GetName());
            }
        }

        // Set move speed
        MyCharacter->GetCharacterMovement()->MaxWalkSpeed = Settings->PatrolMoveSpeed;

        // Start patrol timer
        GetWorldTimerManager().SetTimer(
            PatrolTimerHandle,
            this,
            &AMyAIController::TickBehavior,
            Settings->PatrolInterval,
            true
        );
    }
}

void AMyAIController::InitializePatrolPath()
{
    if (PatrolPath)
    {
        PatrolPoints = PatrolPath->PatrolPoints;

        if (const UMyAIPluginSettings* Settings = GetDefault<UMyAIPluginSettings>())
        {
            if (Settings->bEnableDebugLogs)
            {
                UE_LOG(LogTemp, Warning, TEXT("[AI] Patrol Path Initialized  %d points from: %s"),
                    PatrolPoints.Num(), *PatrolPath->GetName());
            }
        }
    }
    else
    {
        UE_LOG(LogTemp, Warning, TEXT("[AI] InitializePatrolPath failed � PatrolPath is NULL"));
    }
}

void AMyAIController::TickBehavior()
{
    const UMyAIPluginSettings* Settings = GetDefault<UMyAIPluginSettings>();
    if (!Settings || !GetPawn()) return;

    // Try chasing first
    if (HandleChaseBehavior(Settings)) return;

    // Lose the player and sto changing
    if (bWasChasing)
    {
        bWasChasing = false;

        if (Settings->bEnableDebugLogs)
        {
            UE_LOG(LogTemp, Warning, TEXT("[AI] Player lost. Returning to patrol."));
        }
    }

    // Continue patrolling
    HandlePatrolBehavior(Settings);
}

void AMyAIController::MoveToNextPatrolPoint()
{
    const UMyAIPluginSettings* Settings = GetDefault<UMyAIPluginSettings>();
    if (PatrolPoints.Num() == 0) return;

    AActor* Target = PatrolPoints[CurrentPatrolIndex];
    if (!Target) return;

    MoveToActor(Target);

    float WaitTime = Settings->PatrolInterval;

    // Use custom wait time if valid
    if (PatrolPath && CurrentPatrolIndex < PatrolPath->PatrolWaitTimes.Num())
    {
        float CustomWait = PatrolPath->PatrolWaitTimes[CurrentPatrolIndex];
        if (CustomWait > 0.f)
        {
            WaitTime = CustomWait;
        }
    }

    if (Settings->bEnableDebugLogs)
    {
        UE_LOG(LogTemp, Warning, TEXT("[AI] Moving to Patrol Point %d: %s (Wait: %.1fs)"),
            CurrentPatrolIndex,
            *Target->GetName(),
            WaitTime);
    }

    // Set timer to advance patrol index
    GetWorldTimerManager().SetTimer(
        WaypointWaitTimerHandle,
        this,
        &AMyAIController::AdvancePatrolIndex,
        WaitTime,
        false
    );
}

void AMyAIController::MoveAlongSpline()
{
    const UMyAIPluginSettings* Settings = GetDefault<UMyAIPluginSettings>();
    if (!SplinePath || !Settings) return;

    USplineComponent* Spline = SplinePath->SplineComponent;
    int32 NumPoints = Spline->GetNumberOfSplinePoints();
    if (NumPoints == 0) return;

    // Move to next point
    FVector NextPoint = Spline->GetLocationAtSplinePoint(CurrentSplineIndex, ESplineCoordinateSpace::World);
    MoveToLocation(NextPoint);

    if (Settings->bEnableDebugLogs)
    {
        UE_LOG(LogTemp, Warning, TEXT("[AI] Spline  Waiting %.1fs then moving to point %d: %s"),
            Settings->SplineWaitTime, CurrentSplineIndex, *NextPoint.ToString());
    }

    // Progress the spline index
    if (Settings->bUsePingPongSpline)
    {
        if (!bReverseSpline)
        {
            CurrentSplineIndex++;
            if (CurrentSplineIndex >= NumPoints)
            {
                CurrentSplineIndex = NumPoints - 1;
                bReverseSpline = true;
            }
        }
        else
        {
            CurrentSplineIndex--;
            if (CurrentSplineIndex < 0)
            {
                CurrentSplineIndex = 0;
                bReverseSpline = false;
            }
        }
    }
    else
    {
        CurrentSplineIndex = (CurrentSplineIndex + 1) % NumPoints;
    }
}

void AMyAIController::MoveToNextSplinePoint()
{
    if (!SplinePath || !SplinePath->SplineComponent) return;

    const UMyAIPluginSettings* Settings = GetDefault<UMyAIPluginSettings>();
    if (!Settings) return;

    USplineComponent* Spline = SplinePath->SplineComponent;
    int32 NumPoints = Spline->GetNumberOfSplinePoints();
    if (NumPoints == 0) return;

    FVector NextPoint = Spline->GetLocationAtSplinePoint(CurrentSplineIndex, ESplineCoordinateSpace::World);
    MoveToLocation(NextPoint);

    //wait time for each point
    float WaitTime = Settings->SplineWaitTime;
    if (SplinePath->WaitTimes.IsValidIndex(CurrentSplineIndex))
    {
        WaitTime = SplinePath->WaitTimes[CurrentSplineIndex];
    }

    if (Settings->bEnableDebugLogs)
    {
        UE_LOG(LogTemp, Warning, TEXT("[AI] Moving to spline point %d: %s (Wait: %.1fs)"),
            CurrentSplineIndex, *NextPoint.ToString(), WaitTime);
    }

    //Set timer using indivindual point wait time
    GetWorldTimerManager().SetTimer(
        SplineWaitTimerHandle,
        this,
        &AMyAIController::AdvanceSplineIndex,
        WaitTime,
        false
    );
}

void AMyAIController::AdvanceSplineIndex()
{
    if (!SplinePath || !SplinePath->SplineComponent) return;

    USplineComponent* Spline = SplinePath->SplineComponent;
    int32 NumPoints = Spline->GetNumberOfSplinePoints();
    if (NumPoints == 0) return;

    // First, update index
    if (const UMyAIPluginSettings* Settings = GetDefault<UMyAIPluginSettings>())
    {
        if (Settings->bUsePingPongSpline)
        {
            if (!bReverseSpline)
            {
                CurrentSplineIndex++;
                if (CurrentSplineIndex >= NumPoints)
                {
                    CurrentSplineIndex = NumPoints - 2;
                    bReverseSpline = true;
                }
            }
            else
            {
                CurrentSplineIndex--;
                if (CurrentSplineIndex < 0)
                {
                    CurrentSplineIndex = 1;
                    bReverseSpline = false;
                }
            }
        }
        else
        {
            CurrentSplineIndex = (CurrentSplineIndex + 1) % NumPoints;
        }
    }

    // Then move to the next point (new index)
    MoveToNextSplinePoint();
}

void AMyAIController::AdvancePatrolIndex()
{
    if (PatrolPoints.Num() == 0) return;

    CurrentPatrolIndex = (CurrentPatrolIndex + 1) % PatrolPoints.Num();
    MoveToNextPatrolPoint();
}

bool AMyAIController::HandleChaseBehavior(const UMyAIPluginSettings* Settings)
{
    if (!Settings || !PlayerPawn) return false;
    if (Settings->DefaultCombatStyle == EAICombatStyle::EAIC_Passive)
    {
        return false;
    }

    float Distance = FVector::Dist(PlayerPawn->GetActorLocation(), GetPawn()->GetActorLocation());

    if (Distance <= Settings->ChaseDistance)
    {
        if (CurrentAIState != EAIState::EAIS_Chasing)
        {
            CurrentAIState = EAIState::EAIS_Chasing;
            bWasChasing = true;

            if (Settings->bEnableDebugLogs)
            {
                UE_LOG(LogTemp, Warning, TEXT("[AI] State: Chasing Player | Distance: %.2f"), Distance);
            }
        }

        MoveToActor(PlayerPawn);
        AttemptAttack();
        return true;
    }

    //lost vision of the player
    if (bWasChasing)
    {
        if (Settings->bEnableDebugLogs)
        {
            UE_LOG(LogTemp, Warning, TEXT("[AI] Player lost. Returning to patrol."));
        }

        bWasChasing = false;
    }

    return false;
}

void AMyAIController::HandlePatrolBehavior(const UMyAIPluginSettings* Settings)
{
    if (!Settings->bEnablePatrol) return;

    CurrentAIState = EAIState::EAIS_Patrolling;

    switch (Settings->PatrolMode)
    {
    case EPatrolMode::EPM_Waypoints:
        HandleWaypointPatrol(Settings);
        break;

    case EPatrolMode::EPM_Spline:
        HandleSplinePatrol(Settings);
        break;

    case EPatrolMode::EPM_Random:
    default:
        HandleRandomPatrol(Settings);
        break;
    }
}

void AMyAIController::HandleWaypointPatrol(const UMyAIPluginSettings* Settings)
{
    if (PatrolPoints.Num() == 0) return;

    // Prevent multiple timers being set
    if (!GetWorldTimerManager().IsTimerActive(WaypointWaitTimerHandle))
    {
        MoveToNextPatrolPoint();
    }
}

void AMyAIController::HandleSplinePatrol(const UMyAIPluginSettings* Settings)
{
    if (!GetWorldTimerManager().IsTimerActive(SplineWaitTimerHandle))
    {
        MoveToNextSplinePoint();
    }
}

void AMyAIController::HandleRandomPatrol(const UMyAIPluginSettings* Settings)
{
    UNavigationSystemV1* NavSystem = UNavigationSystemV1::GetCurrent(GetWorld());
    if (!NavSystem) return;

    FVector Destination;
    if (NavSystem->K2_GetRandomReachablePointInRadius(GetWorld(), GetPawn()->GetActorLocation(), Destination, Settings->PatrolRadius))
    {
        if (Settings->bEnableDebugLogs)
        {
            UE_LOG(LogTemp, Warning, TEXT("[AI] State: %s | Patrolling to random location: %s"),
                *UEnum::GetValueAsString(CurrentAIState),
                *Destination.ToString());
        }

        MoveToLocation(Destination);
    }
}


void AMyAIController::AttemptAttack()
{
    const UMyAIPluginSettings* Settings = GetDefault<UMyAIPluginSettings>();
    if (!Settings || !Settings->bEnableAttack || !bCanAttack || !PlayerPawn) return;
    // Handle Passive Style: never attacks
    if (Settings->DefaultCombatStyle == EAICombatStyle::EAIC_Passive)
    {
        return;
    }
    // Handle Defensive Style: only attack if provoked
    if (Settings->DefaultCombatStyle == EAICombatStyle::EAIC_Defensive && !bWasChasing)
    {
        return;
    }

    float Distance = FVector::Dist(PlayerPawn->GetActorLocation(), GetPawn()->GetActorLocation());

    if (Distance <= Settings->AttackRange)
    {
        // Update AI state
        CurrentAIState = EAIState::EAIS_Attacking;

        if (Settings->bEnableDebugLogs)
        {
            UE_LOG(LogTemp, Warning, TEXT("Attacking Player! Distance: % f"), Distance);
        }

        // Timer for attacking after some sec
        bCanAttack = false;
        GetWorldTimerManager().SetTimer(
            AttackTimerHandle,
            [this]() { bCanAttack = true; },
            Settings->AttackCooldown,
            false
        );

        // Draw a red debug sphere to visualize the attack
        DrawDebugSphere(
            GetWorld(),
            GetPawn()->GetActorLocation(),
            Settings->AttackRange,
            12,
            FColor::Red,
            false,
            1.0f);
    }
}



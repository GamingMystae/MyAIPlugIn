// Fill out your copyright notice in the Description page of Project Settings.


#include "SplinePath.h"
#include "Components/SplineComponent.h"

// Sets default values
ASplinePath::ASplinePath()
{
	PrimaryActorTick.bCanEverTick = false;

	SplineComponent = CreateDefaultSubobject<USplineComponent>(TEXT("SplineComponent"));
	SetRootComponent(SplineComponent);

}

// Called when the game starts or when spawned
void ASplinePath::BeginPlay()
{
	Super::BeginPlay();
	
}

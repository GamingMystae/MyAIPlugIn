// Fill out your copyright notice in the Description page of Project Settings.

/******************************
** MY CUSTOM AI Character CPP *
******************************/

#include "NPC_Character.h"
#include "MyAIController.h"

ANPC_Character::ANPC_Character()
{
	//PrimaryActorTick.bCanEverTick = true;

	// set the AIControllerclass as the new custom AI controller class
	AIControllerClass = AMyAIController::StaticClass();

}

void ANPC_Character::BeginPlay()
{
	Super::BeginPlay();
	UE_LOG(LogTemp, Warning, TEXT("NPC_Character Spawned!"));
	
}
/*
void ANPC_Character::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}*/


